package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.utils.ScreenUtils;
import jdk.tools.jmod.Main;

import java.awt.*;

public class ChooseTankMenuScreen extends Game implements Screen {


    private final MyGdxGame game;

    private Texture chooseTankScreenImage;
    private Texture player1screen1;
    private Texture player1screen2;
    private Texture player1screen3;

    public MyGdxGame getGame() {
        return game;
    }

    public Texture getChooseTankScreenImage() {
        return chooseTankScreenImage;
    }

    public void setChooseTankScreenImage(Texture chooseTankScreenImage) {
        this.chooseTankScreenImage = chooseTankScreenImage;
    }

    public Texture getPlayer1screen1() {
        return player1screen1;
    }

    public void setPlayer1screen1(Texture player1screen1) {
        this.player1screen1 = player1screen1;
    }

    public Texture getPlayer1screen2() {
        return player1screen2;
    }

    public void setPlayer1screen2(Texture player1screen2) {
        this.player1screen2 = player1screen2;
    }

    public Texture getPlayer1screen3() {
        return player1screen3;
    }

    public void setPlayer1screen3(Texture player1screen3) {
        this.player1screen3 = player1screen3;
    }

    public OrthographicCamera getCamera() {
        return camera;
    }

    public void setCamera(OrthographicCamera camera) {
        this.camera = camera;
    }

    private OrthographicCamera camera;

    ChooseTankMenuScreen(final MyGdxGame game){
        this.game=game;

        camera = new OrthographicCamera();
        camera.setToOrtho(false,800,480);

        chooseTankScreenImage= new Texture(Gdx.files.internal("1.png"));
        player1screen1=new Texture(Gdx.files.internal("2.png"));
        player1screen2=new Texture(Gdx.files.internal("3.png"));
        player1screen3=new Texture(Gdx.files.internal("4.png"));


    }



    @Override
    public void create() {

    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0.2f,1);

        camera.update();
        game.getBatch().setProjectionMatrix(camera.combined);

        game.getBatch().begin();
        game.getBatch().draw(chooseTankScreenImage,0,0,800,480);
        game.getBatch().end();

        if (Gdx.input.justTouched()){


            if (Gdx.input.getX()>25 && Gdx.input.getX()<160 && Gdx.input.getY()>10 && Gdx.input.getY()<90){
                choosePrevScreen();
            }

            else if (Gdx.input.getX()>90 && Gdx.input.getX()<240 && Gdx.input.getY()>230 && Gdx.input.getY()<379){
                choosePlayer1Screen1();
            }
            else if (Gdx.input.getX()>315 && Gdx.input.getX()<461 && Gdx.input.getY()>230 && Gdx.input.getY()<379){
                choosePlayer1Screen2();
            }
            else if (Gdx.input.getX()>544 && Gdx.input.getX()<688 && Gdx.input.getY()>230 && Gdx.input.getY()<379){
                choosePlayer1Screen3();
            }


        }

    }

    public void chooseNextScreen(){
        game.setScreen(new ChooseTankMenuScreen2(game));
    }
    public void choosePrevScreen(){
        game.setScreen(new MainMenuScreen(game));
    }
    public void choosePlayer1Screen1(){




        game.getBatch().begin();
        game.getBatch().draw(player1screen1,0,0,800,480);
        game.getBatch().end();
        chooseNextScreen();
    }
    public void choosePlayer1Screen2(){

        game.getBatch().begin();
        game.getBatch().draw(player1screen2,0,0,800,480);
        game.getBatch().end();
        chooseNextScreen();
    }
    public void choosePlayer1Screen3(){

        game.getBatch().begin();
        game.getBatch().draw(player1screen3,0,0,800,480);
        game.getBatch().end();
        chooseNextScreen();
    }

    @Override
    public void hide() {

    }
}
