package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;

public class ExitScreen implements Screen {

    private final MyGdxGame game;
    private Texture exitgameimage;
    private OrthographicCamera camera;

    public ExitScreen(final MyGdxGame game) {
        this.game = game;
        camera = new OrthographicCamera();
        camera.setToOrtho(false,800,480);
        exitgameimage = new Texture(Gdx.files.internal("12.png"));
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0.2902f, 0.6784f, 1);
        camera.update();
        game.getBatch().setProjectionMatrix(camera.combined);

        game.getBatch().begin();
        game.getBatch().draw(exitgameimage,0,0,800,480);
        game.getBatch().end();


        if (Gdx.input.justTouched()){

            if (Gdx.input.getX()>301 && Gdx.input.getX()<494 && Gdx.input.getY()<220 && Gdx.input.getY()>145){
                loadInGameScreen();
            }
            else if (Gdx.input.getX()>302 && Gdx.input.getX()<493 && Gdx.input.getY()>276 && Gdx.input.getY()<350){
                loadMainMenuScreen();
            }



        }

    }


    public void loadInGameScreen(){
        game.setScreen(new InGameScreen(game));
    }

    public void loadMainMenuScreen(){
        game.setScreen(new MainMenuScreen(game));
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
