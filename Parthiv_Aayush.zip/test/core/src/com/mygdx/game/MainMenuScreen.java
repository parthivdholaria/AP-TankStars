package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import jdk.tools.jmod.Main;

import java.awt.*;

public class MainMenuScreen extends Game implements Screen {


    final MyGdxGame game;

    private BitmapFont font;


    private Texture homepageImage;
    private Texture onevoneImage;
    private Texture ResumeImage;
    private Texture ExitImage;


    private OrthographicCamera camera;

    private Stage stage;

    public MyGdxGame getGame() {
        return game;
    }

    public BitmapFont getFont() {
        return font;
    }

    public void setFont(BitmapFont font) {
        this.font = font;
    }

    public Texture getHomepageImage() {
        return homepageImage;
    }

    public void setHomepageImage(Texture homepageImage) {
        this.homepageImage = homepageImage;
    }

    public Texture getOnevoneImage() {
        return onevoneImage;
    }

    public void setOnevoneImage(Texture onevoneImage) {
        this.onevoneImage = onevoneImage;
    }

    public Texture getResumeImage() {
        return ResumeImage;
    }

    public void setResumeImage(Texture resumeImage) {
        ResumeImage = resumeImage;
    }

    public Texture getExitImage() {
        return ExitImage;
    }

    public void setExitImage(Texture exitImage) {
        ExitImage = exitImage;
    }

    public OrthographicCamera getCamera() {
        return camera;
    }

    public void setCamera(OrthographicCamera camera) {
        this.camera = camera;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public TextureAtlas getButtonAtlas() {
        return buttonAtlas;
    }

    public void setButtonAtlas(TextureAtlas buttonAtlas) {
        this.buttonAtlas = buttonAtlas;
    }

    private TextureAtlas buttonAtlas;

    MainMenuScreen(final MyGdxGame game){

        this.stage = new Stage();
        this.game=game;
        font = new BitmapFont();
        homepageImage = new Texture(Gdx.files.internal("homepage.jpg"));
        onevoneImage = new Texture(Gdx.files.internal("onevone.PNG"));
        ResumeImage = new Texture(Gdx.files.internal("Resume.png"));
        ExitImage = new Texture(Gdx.files.internal("Exit.png"));



        camera=new OrthographicCamera();
        camera.setToOrtho(false,800,480);



    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {


        ScreenUtils.clear(0, 0.2902f, 0.6784f, 1);


        camera.update();
        game.getBatch().setProjectionMatrix(camera.combined);

        game.getBatch().begin();
        game.getBatch().draw(homepageImage,0,0,600,480);
        game.getBatch().draw(onevoneImage,632,314,128,64);
        game.getBatch().draw(ResumeImage,632,240,128,64);
        game.getBatch().draw(ExitImage,632,166,128,64);
        game.getBatch().end();

        if (Gdx.input.isTouched()){

            if (Gdx.input.getX()>630 && Gdx.input.getX()<760 && Gdx.input.getY()>100 && Gdx.input.getY()<170){
                loadGame();
            }
            if (Gdx.input.getX()>630 && Gdx.input.getX()<760 && Gdx.input.getY()>178 && Gdx.input.getY()<234){
                ResumeGame();
            }
            if (Gdx.input.getX()>630 && Gdx.input.getX()<760 &&  Gdx.input.getY()>250 && Gdx.input.getY()<312){
                Gdx.app.exit();
            }
        }


    }

    public void loadGame(){
        game.setScreen(new ChooseTankMenuScreen(game));
    }
    public void ResumeGame(){
        game.setScreen(new ResumeScreen(game));
    }

    @Override
    public void create() {



    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
