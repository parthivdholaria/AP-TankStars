package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import jdk.internal.math.FDBigInteger;
import org.w3c.dom.Text;

public class PauseScreen extends Game implements Screen {

    private final MyGdxGame game;
    private Texture pausescreenimage;
    private OrthographicCamera camera;

    PauseScreen(final MyGdxGame game){
        this.game=game;
        camera=new OrthographicCamera();
        camera.setToOrtho(false,800,480);

        pausescreenimage = new Texture(Gdx.files.internal("11.png"));

    }

    @Override
    public void create() {

    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0.2902f, 0.6784f, 1);
        camera.update();
        game.getBatch().setProjectionMatrix(camera.combined);

        game.getBatch().begin();
        game.getBatch().draw(pausescreenimage,0,0,800,480);
        game.getBatch().end();

        if (Gdx.input.justTouched()){


            if (Gdx.input.getX()>300 && Gdx.input.getX()<500 && Gdx.input.getY()>125 && Gdx.input.getY()<200){
                loadNextScreen();
            }
            else if (Gdx.input.getX()>300 && Gdx.input.getX()<500 && Gdx.input.getY()>350 && Gdx.input.getY()<422){
                loadPrevScreen();
            }

        }

    }

    public void loadNextScreen(){
        game.setScreen(new InGameScreen(game));
    }
    public void loadPrevScreen(){
        game.setScreen(new ResumeScreen(game));
    }

    @Override
    public void hide() {

    }
}
