package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;

import java.awt.*;

public class LoadingScreen implements Screen {

    private final MyGdxGame game;
    private Texture LoadingScreenImage;
    private OrthographicCamera camera;

    private Rectangle mainScreen;

    public MyGdxGame getGame() {
        return game;
    }

    public Texture getLoadingScreenImage() {
        return LoadingScreenImage;
    }

    public void setLoadingScreenImage(Texture loadingScreenImage) {
        LoadingScreenImage = loadingScreenImage;
    }

    public OrthographicCamera getCamera() {
        return camera;
    }

    public void setCamera(OrthographicCamera camera) {
        this.camera = camera;
    }

    public Rectangle getMainScreen() {
        return mainScreen;
    }

    public void setMainScreen(Rectangle mainScreen) {
        this.mainScreen = mainScreen;
    }



    public LoadingScreen(final MyGdxGame game){
        this.game = game;

        LoadingScreenImage = new Texture(Gdx.files.internal("front.png"));


        camera = new OrthographicCamera();
        camera.setToOrtho(false,800,480);

        mainScreen = new Rectangle();
        mainScreen.x=0;
        mainScreen.y=0;
        mainScreen.width=800;
        mainScreen.height=480;
    }




    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0.2902f, 0.6784f, 1);
        camera.update();

        game.getBatch().setProjectionMatrix(camera.combined);

        game.getBatch().begin();
        game.getBatch().draw(LoadingScreenImage,mainScreen.x,mainScreen.y,mainScreen.width,mainScreen.height);
        game.getBatch().end();



        
        if (Gdx.input.isTouched()){
            if (Gdx.input.getX()>241 && Gdx.input.getX()<559 && Gdx.input.getY()>397 && Gdx.input.getY()<466){
                game.setScreen(new MainMenuScreen(game));
            }
        }

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        LoadingScreenImage.dispose();
    }
}
